let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
}

function draw() {
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208),
    map(totalArvores, 0, 100, 0, 1));
  background(corFundo);

  mostrarInformacoes();

  temperatura += 0.1;

  jardineiro.atualizar();
  jardineiro.mostrar();

  verificaFimDeJogo();

  plantas.forEach((arvore) => arvore.mostrar());
}

function mostrarInformacoes() {
  textSize(16);
  fill(0);
  text('Temperatura: ' + temperatura.toFixed(2), 10, 30);
  text('Árvores plantadas: ' + totalArvores, 10, 50);
  text('Para movimentar o personagem use as setas do teclado.', 10, 80);
}

function verificaFimDeJogo() {
  if (totalArvores > temperatura) {
    mostrarMensagemDeVitoria();
  } else if (temperatura > 50) {
    mostrarMensagemDeDerrota();
  }
}

function mostrarMensagemDeVitoria() {
  textSize(20);
  fill(0, 128, 0);
  text('Você venceu!', 100, 200);
  noLoop();
}

function mostrarMensagemDeDerrota() {
  textSize(20);
  fill(255, 0, 0);
  text('Você perdeu!', 100, 200);
  noLoop();
}

function keyPressed() {
  if (key === ' ' || key === 'p') {
    // Distribuição natural das árvores ao redor do jardineiro
    let offsetX = random(-30, 30);
    let offsetY = random(-30, 30);
    let arvore = new Arvore(jardineiro.x + offsetX, jardineiro.y + offsetY);
    plantas.push(arvore);
    totalArvores++;
    temperatura -= 3;
    if (temperatura < 0) temperatura = 0;
  }
}

class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '👨‍🌾';
    this.velocidade = 3;
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limites da tela
    this.x = constrain(this.x, 0, width - 32);
    this.y = constrain(this.y, 0, height - 32);
  }

  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🌳';
  }

  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

