let telaAtual = 0; // 0: Menu, 1: Jogo, 2: Final

let fazendeiro;

let produtos = [];

let pontuacao = 0;

let dinheiro = 0;

let tempoRestante = 60; // Reduzido para um jogo mais dinâmico

let timerInterval;

let mensagemTemporaria = ""; // Para mensagens na tela

let duracaoMensagem = 0;

// Emojis

let emojiFazendeiro = '👨‍🌾'; // Ou '🧑‍🌾', '👩‍🌾'

let emojisFrutas = ['🍎', '🍓', '🍇', '🥭', '🍍', '🍊']; // Mais variedade

let emojiDinheiro = '💰';

let emojiPontos = '🌟';

let emojiTempo = '⏱️';

let emojiMochila = '🎒'; // Emoji para a mochila

// Cores aprimoradas

let corCampo = [120, 200, 80];    // Verde vibrante

let corCidade = [180, 180, 180];  // Cinza claro da cidade

let corEstrada = [90, 90, 90];    // Cinza escuro da estrada

let corBotaoPrincipal = [50, 180, 255]; // Azul para botões

let corBotaoVender = [255, 80, 80];     // Vermelho vivo para vender

function setup() {
  createCanvas(windowWidth * 0.9, windowHeight * 0.9);
  if (width > 700) width = 700;
  if (height > 500) height = 500;

  fazendeiro = new Fazendeiro();
  textAlign(CENTER, CENTER);

  timerInterval = setInterval(contarTempo, 1000);
}

function draw() {
  if (telaAtual === 0) {
    mostrarMenu();
  } else if (telaAtual === 1) {
    jogar();
  } else if (telaAtual === 2) {
    mostrarFinal();
  }
}

function mostrarMenu() {
  background(corCampo[0], corCampo[1], corCampo[2]);
  textSize(width * 0.08);
  fill(255);
  text("🌱 Campo & Cidade 🏙️", width / 2, height * 0.3);

  textSize(width * 0.04);
  fill(240);
  text("Colha, Entregue, Cumpra!", width / 2, height * 0.45);

  let btnRaio = width * 0.15;
  fill(corBotaoPrincipal[0], corBotaoPrincipal[1], corBotaoPrincipal[2], 200 + sin(frameCount * 0.05) * 50);
  ellipse(width / 2, height * 0.7, btnRaio * 2);

  fill(255);
  textSize(width * 0.05);
  text("JOGAR", width / 2, height * 0.7);
}

function jogar() {
  desenharCenario();
  fazendeiro.mostrar();
  fazendeiro.atualizar();

  for (let i = produtos.length - 1; i >= 0; i--) {
    produtos[i].mostrar();
    produtos[i].mover();
    if (produtos[i].y > height + produtos[i].tamanho) {
      produtos.splice(i, 1);
    }
  }

  if (frameCount % 45 === 0 && tempoRestante > 0) {
    criarProdutoAleatorio();
  }

  desenharUI();

  if (duracaoMensagem > 0) {
    fill(255, 0, 0);
    textSize(width * 0.04);
    text(mensagemTemporaria, width / 2, height * 0.5);
    duracaoMensagem--;
  }

  if (tempoRestante <= 0) {
    telaAtual = 2;
    clearInterval(timerInterval);
  }
}

function mostrarFinal() {
  background(50);
  textSize(width * 0.08);
  fill(255, 220, 0);
  text("🎉 Jogo Concluído! 🎉", width / 2, height * 0.3);

  textSize(width * 0.05);
  fill(255);
  text(`${emojiPontos} Pontos: ${pontuacao}`, width / 2, height * 0.45);
  text(`${emojiDinheiro} Dinheiro: R$${dinheiro.toFixed(0)}`, width / 2, height * 0.55);

  textSize(width * 0.035);
  fill(200);
  text("Toque para jogar de novo!", width / 2, height * 0.75);
}

function touchStarted() {
  if (telaAtual === 0) {
    let btnRaio = width * 0.15;
    if (dist(mouseX, mouseY, width / 2, height * 0.7) < btnRaio) {
      telaAtual = 1;
      resetJogo();
    }
  } else if (telaAtual === 1) {
    let btnVenderRaio = width * 0.08;
    if (dist(touches[0].x, touches[0].y, width - btnVenderRaio, btnVenderRaio) < btnVenderRaio) {
      fazendeiro.vender();
    } else {
      fazendeiro.definirAlvo(touches[0].x, touches[0].y);
    }
  } else if (telaAtual === 2) {
    telaAtual = 0;
  }
  return false;
}

function touchMoved() {
  if (telaAtual === 1) {
    fazendeiro.definirAlvo(touches[0].x, touches[0].y);
  }
  return false;
}

function touchEnded() {
  if (telaAtual === 1) {
    fazendeiro.pararMovimento();
  }
  return false;
}

function desenharCenario() {
  background(135, 206, 235);
  fill(corCampo[0], corCampo[1], corCampo[2]);
  rect(width / 2, height * 0.75, width, height * 0.5);

  fill(corEstrada[0], corEstrada[1], corEstrada[2]);
  rect(width / 2, height * 0.5, width, height * 0.2);

  stroke(255, 255, 0);
  strokeWeight(width * 0.005);
  for (let i = 0; i < width + 40; i += 40) {
    line(i - (frameCount % 40), height * 0.5, i + 20 - (frameCount % 40), height * 0.5);
  }
  noStroke();

  fill(corCidade[0], corCidade[1], corCidade[2]);
  rect(width / 2, height * 0.2, width, height * 0.4);

  fill(100, 100, 100);
  rect(width * 0.2, height * 0.15, width * 0.1, height * 0.15);
  fill(200, 200, 0, 150);
  rect(width * 0.18, height * 0.13, width * 0.02, height * 0.02);
  rect(width * 0.22, height * 0.16, width * 0.02, height * 0.02);
  fill(100, 100, 100);
  rect(width * 0.8, height * 0.25, width * 0.12, height * 0.08);
  fill(200, 200, 0, 150);
  rect(width * 0.77, height * 0.24, width * 0.02, height * 0.02);
  rect(width * 0.83, height * 0.26, width * 0.02, height * 0.02);
}

function desenharUI() {
  fill(0, 0, 0, 180);
  rect(width * 0.25, height * 0.08, width * 0.45, height * 0.12);

  fill(255);
  textSize(width * 0.03);
  textAlign(LEFT, TOP);
  text(`${emojiPontos} ${pontuacao}`, width * 0.05, height * 0.03);
  text(`${emojiDinheiro} R$${dinheiro.toFixed(0)}`, width * 0.05, height * 0.07);
  text(`${emojiTempo} ${nf(tempoRestante, 2)}s`, width * 0.05, height * 0.11);

  fill(corBotaoVender[0], corBotaoVender[1], corBotaoVender[2]);
  let btnVenderRaio = width * 0.08;
  ellipse(width - btnVenderRaio, btnVenderRaio, btnVenderRaio * 2);

  fill(255);
  textSize(width * 0.03);
  textAlign(CENTER, CENTER);
  text("VENDER", width - btnVenderRaio, btnVenderRaio);
}

function contarTempo() {
  if (telaAtual === 1) {
    tempoRestante--;
  }
}

function criarProdutoAleatorio() {
  let xPos = random(width * 0.1, width * 0.9);
  let yPos = height * 0.75 + random(20, 50);
  let tipoFruta = random(emojisFrutas);
  produtos.push(new Produto(xPos, yPos, tipoFruta));
}

function exibirMensagem(msg) {
  mensagemTemporaria = msg;
  duracaoMensagem = 60;
}

function resetJogo() {
  pontuacao = 0;
  dinheiro = 0;
  tempoRestante = 60;
  produtos = [];
  fazendeiro = new Fazendeiro();
  clearInterval(timerInterval);
  timerInterval = setInterval(contarTempo, 1000);
}

class Fazendeiro {
  constructor() {
    this.x = width / 2;
    this.y = height * 0.75;
    this.tamanho = width * 0.08;
    this.inventario = 0;
    this.alvoX = this.x;
    this.alvoY = this.y;
    this.velocidadeMovimento = width * 0.015;
  }

  mostrar() {
    textSize(this.tamanho);
    text(emojiFazendeiro, this.x, this.y);

    if (this.inventario > 0) {
      textSize(this.tamanho * 0.6);
      text(emojiMochila, this.x + this.tamanho * 0.4, this.y);
      fill(255);
      textSize(this.tamanho * 0.4);
      text(this.inventario, this.x + this.tamanho * 0.45, this.y + this.tamanho * 0.1);
    }
  }

  definirAlvo(x, y) {
    this.alvoX = constrain(x, this.tamanho / 2, width - this.tamanho / 2);
    this.alvoY = constrain(y, height * 0.4 + this.tamanho / 2, height - this.tamanho / 2);
  }

  pararMovimento() {
    this.alvoX = this.x;
    this.alvoY = this.y;
  }

  atualizar() {
    let distancia = dist(this.x, this.y, this.alvoX, this.alvoY);
    if (distancia > this.velocidadeMovimento) {
      let angulo = atan2(this.alvoY - this.y, this.alvoX - this.x);
      this.x += cos(angulo) * this.velocidadeMovimento;
      this.y += sin(angulo) * this.velocidadeMovimento;
    } else {
      this.x = this.alvoX;
      this.y = this.alvoY;
    }

    for (let i = produtos.length - 1; i >= 0; i--) {
      let d = dist(this.x, this.y, produtos[i].x, produtos[i].y);
      if (d < this.tamanho / 2 + produtos[i].tamanho / 2) {
        this.inventario++;
        pontuacao += 5;
        produtos.splice(i, 1);
      }
    }
  }

  vender() {
    if (this.y < height * 0.5) {
      if (this.inventario > 0) {
        dinheiro += this.inventario * 15;
        pontuacao += this.inventario * 15;
        this.inventario = 0;
        exibirMensagem("Venda Realizada! 💰");
      } else {
        exibirMensagem("Mochila Vazia! 🎒");
      }
    } else {
      exibirMensagem("Vá para a cidade para vender! 🏙️");
    }
  }
}

class Produto {
  constructor(x, y, emoji) {
    this.x = x;
    this.y = y;
    this.tamanho = width * 0.06;
    this.velocidade = random(1.5, 3.5);
    this.emoji = emoji;
  }

  mostrar() {
    textSize(this.tamanho);
    text(this.emoji, this.x, this.y);
  }

  mover() {
    this.y -= this.velocidade;
  }
}

function windowResized() {
  setup();
}

// NOVO: Movimento com teclado (setas ou WASD)
function keyPressed() {
  if (telaAtual === 1) {
    let passo = fazendeiro.velocidadeMovimento * 5;

    if (key === 'w' || keyCode === UP_ARROW) {
      fazendeiro.definirAlvo(fazendeiro.x, fazendeiro.y - passo);
    } else if (key === 's' || keyCode === DOWN_ARROW) {
      fazendeiro.definirAlvo(fazendeiro.x, fazendeiro.y + passo);
    } else if (key === 'a' || keyCode === LEFT_ARROW) {
      fazendeiro.definirAlvo(fazendeiro.x - passo, fazendeiro.y);
    } else if (key === 'd' || keyCode === RIGHT_ARROW) {
      fazendeiro.definirAlvo(fazendeiro.x + passo, fazendeiro.y);
    }
  }
}
